package org.sp.billing.services;

import org.sp.billing.beans.Shopper;

public interface InvoiceService {
    void generate(Shopper shopper);
    void print(Shopper shopper);
}
