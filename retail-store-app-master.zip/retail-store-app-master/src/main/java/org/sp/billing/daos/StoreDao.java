package org.sp.billing.daos;

import java.util.Set;
import java.util.UUID;

import org.sp.billing.beans.Product;

public interface StoreDao {
    boolean updateInventory(Product product);

    boolean updateInventoryBatch(Set<Product> products);

    Product getProduct(UUID pid);

    Set<Product> getAllProducts();
}
