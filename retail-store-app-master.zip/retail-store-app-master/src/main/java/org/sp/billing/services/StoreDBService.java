package org.sp.billing.services;

import java.util.Set;
import java.util.UUID;

import org.sp.billing.beans.Product;

public interface StoreDBService {
    Set<Product> getInventory();

    boolean isTransactionAllowed(UUID pid, int quantity);

    void updateInventory(Set<Product> cartProducts);
}
