package org.sp.billing.strategies.impls;

import java.util.LinkedHashSet;
import java.util.Set;

import org.sp.billing.beans.Product;
import org.sp.billing.exceptions.InventoryShortageException;
import org.sp.billing.helpers.Utility;
import org.sp.billing.strategies.CartLoadingStrategy;

public class MyCartLoadingStrategy implements CartLoadingStrategy {
    @Override
    public Set<Product> loadNEachFromInventory(Set<Product> inventory, int loadQuantity)
            throws InventoryShortageException {
        Set<Product> cartProducts = new LinkedHashSet<>();
        for (Product p : inventory) {
            Product clone = null;
            try {
                clone = (Product) p.clone();
            } catch (CloneNotSupportedException e) {
                Utility.println(e.getMessage());
                e.printStackTrace();
            }
            if(loadQuantity <= p.getQuantity()){
                clone.setQuantity(loadQuantity);
            }
            else {
                throw new InventoryShortageException();
            }
            cartProducts.add(clone);
        }
        return cartProducts;
    }
}
