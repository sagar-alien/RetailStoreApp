package org.sp.billing.constants;

public enum UserTypes {
    EMPLOYEE,
    AFFILIATE,
    CUSTOMER;
}
