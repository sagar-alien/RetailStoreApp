package org.sp.billing.strategies;

import java.util.Set;

import org.sp.billing.beans.Product;
import org.sp.billing.exceptions.InventoryShortageException;

public interface CartLoadingStrategy {
    Set<Product> loadNEachFromInventory(Set<Product> inventory, int loadQuantity) throws InventoryShortageException;
}
