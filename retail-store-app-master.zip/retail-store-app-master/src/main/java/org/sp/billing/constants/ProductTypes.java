package org.sp.billing.constants;

public enum ProductTypes {
    GROCERY,
    ELECTRONICS,
    CLOTHING,
    STATIONERY,
    COSMETICS;
}
