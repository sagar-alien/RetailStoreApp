package org.sp.billing.strategies;

import org.sp.billing.beans.Shopper;

public interface InvoicingStrategy {
    void generate(Shopper shopper);
}
