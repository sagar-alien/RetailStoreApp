package org.sp.billing.strategies;

import org.sp.billing.beans.Products;

public interface StoreDBStrategy {
    ThreadLocal<Products> getProductInventory();
}
