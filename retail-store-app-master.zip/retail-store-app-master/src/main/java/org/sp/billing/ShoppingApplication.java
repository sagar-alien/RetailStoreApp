package org.sp.billing;

import org.sp.billing.beans.Shopper;
import org.sp.billing.beans.ShoppingCart;
import org.sp.billing.beans.UserDetails;
import org.sp.billing.constants.ApplicationConstants;
import org.sp.billing.exceptions.InventoryShortageException;
import org.sp.billing.services.InvoiceService;
import org.sp.billing.services.StoreDBService;
import org.sp.billing.services.impls.MyCartService;

public class ShoppingApplication {

    private final StoreDBService myStoreDBService;
    private final MyCartService myCartService;
    private final InvoiceService myInvoiceService;

    public ShoppingApplication(StoreDBService myStoreDBService,
                               MyCartService myCartService,
                               InvoiceService myInvoiceService) {
        this.myStoreDBService = myStoreDBService;
        this.myCartService = myCartService;
        this.myInvoiceService = myInvoiceService;
    }

    public double shop(UserDetails userDetails) throws InventoryShortageException {

        ShoppingCart shoppingCart = myCartService.getNewShoppingCart();
        Shopper shopper = new Shopper(userDetails, shoppingCart);

        //Shopping Business Logic
        myCartService.loadNEachFromInventory(
                (int) ApplicationConstants.CART_QUANTITY.getApplicationConstant(),
                shoppingCart);

        myStoreDBService.updateInventory(myCartService.getAllProducts(shoppingCart));
        myInvoiceService.generate(shopper);
        myInvoiceService.print(shopper);
        return shopper.getInvoice().getAmount();
    }


}
